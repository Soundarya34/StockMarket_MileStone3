package com.example.springMvcExample.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.springMvcExample.dao.StockPriceDao;

import com.example.springMvcExample.model.StockPrice;

@RestController
public class StockPriceRestController {

	@Autowired
	StockPriceDao stockPriceDao;

	@GetMapping("/stockPriceDisplay/{companyCode}")
	public List<StockPrice> StockPriceList(@PathVariable("companyCode") int companyCode) {

		return stockPriceDao.findBycompanyCode(companyCode);
	}
}
