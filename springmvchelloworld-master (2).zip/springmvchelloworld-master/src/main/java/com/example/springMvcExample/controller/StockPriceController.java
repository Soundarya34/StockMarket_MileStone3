package com.example.springMvcExample.controller;

public interface StockPriceController {

}
