package com.example.springMvcExample.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.springMvcExample.dao.IPOPlannedDao;

import com.example.springMvcExample.model.IPOPlanned;

@RestController
public class IPORestController {

	@Autowired
	IPOPlannedDao ipoPlannedDao;

	@GetMapping("/ipoDisplay/{companyCode}")
	public List<IPOPlanned> StockPriceList(@PathVariable("companyCode") int companyCode) {

		return ipoPlannedDao.findBycompanyCode(companyCode);
	}

}
