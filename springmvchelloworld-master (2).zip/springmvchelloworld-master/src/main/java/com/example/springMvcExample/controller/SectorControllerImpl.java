package com.example.springMvcExample.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.example.springMvcExample.model.Sector;


import com.example.springMvcExample.service.SectorService;


@Controller
public class SectorControllerImpl implements SectorController {

	@Autowired
	private SectorService sectorService;

	

	@Override
	public boolean insertSector(Sector sector) throws SQLException {
		return sectorService.insertSector(sector);

	}

	@RequestMapping(path = "/registerSectorPage", method = RequestMethod.GET)
	public ModelAndView registerSectorPage(Model model) throws Exception {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("registerSector");
		model.addAttribute("sector", new Sector());
		return mv;
	}

	@RequestMapping(value = "/registerSector", method = RequestMethod.GET)
	public ModelAndView registerSector(@Valid @ModelAttribute("sector") Sector sector, BindingResult result,
			HttpServletRequest request, HttpSession session, ModelMap map) throws SQLException {
		ModelAndView mav = null;
		if (result.hasErrors()) {

			map.addAttribute("sector", sector);
			mav = new ModelAndView("registerSector");
			return mav;
		}

		else {
			map.addAttribute("sector", sector);
			sectorService.insertSector(sector);
			mav = new ModelAndView("sectorList");
			mav.addObject("sectorList", sectorService.getSectorList());
			return mav;
		}

	}

	@RequestMapping(path = "/sectorList")
	public ModelAndView getSectorList() throws Exception {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("sectorList");
		mv.addObject("sectorList", sectorService.getSectorList());
		return mv;
	}

	
	
	

}